export default function InsuranceSummary({ data }) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h3 className="text-xl font-semibold mb-4">Insurance Summary</h3>
      {/* Display insurance summary data */}
    </div>
  )
}

